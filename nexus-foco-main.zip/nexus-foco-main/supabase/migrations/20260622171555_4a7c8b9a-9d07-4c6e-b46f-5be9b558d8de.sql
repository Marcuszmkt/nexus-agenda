
ALTER TABLE public.events ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'common';
ALTER TABLE public.all_day_events ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'common';
ALTER TABLE public.tasks ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'common';
