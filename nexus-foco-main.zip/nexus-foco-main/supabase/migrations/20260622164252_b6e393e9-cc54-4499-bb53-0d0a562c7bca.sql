ALTER TABLE public.goals
  ADD COLUMN IF NOT EXISTS type text NOT NULL DEFAULT 'unique',
  ADD COLUMN IF NOT EXISTS current_value numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS target_value numeric NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS unit text;

ALTER TABLE public.goals
  DROP CONSTRAINT IF EXISTS goals_type_check;
ALTER TABLE public.goals
  ADD CONSTRAINT goals_type_check CHECK (type IN ('unique','quantity'));