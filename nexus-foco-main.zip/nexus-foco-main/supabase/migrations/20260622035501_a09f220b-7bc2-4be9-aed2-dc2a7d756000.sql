
-- tasks
CREATE TABLE public.tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  scheduled_date date NOT NULL,
  scheduled_time time NULL,
  completed boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tasks TO anon, authenticated;
GRANT ALL ON public.tasks TO service_role;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read tasks" ON public.tasks FOR SELECT USING (true);
CREATE POLICY "Public insert tasks" ON public.tasks FOR INSERT WITH CHECK (true);
CREATE POLICY "Public update tasks" ON public.tasks FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "Public delete tasks" ON public.tasks FOR DELETE USING (true);
ALTER PUBLICATION supabase_realtime ADD TABLE public.tasks;
ALTER TABLE public.tasks REPLICA IDENTITY FULL;

-- goals
CREATE TABLE public.goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  completed boolean NOT NULL DEFAULT false,
  year integer NOT NULL DEFAULT 2026,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.goals TO anon, authenticated;
GRANT ALL ON public.goals TO service_role;
ALTER TABLE public.goals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read goals" ON public.goals FOR SELECT USING (true);
CREATE POLICY "Public insert goals" ON public.goals FOR INSERT WITH CHECK (true);
CREATE POLICY "Public update goals" ON public.goals FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "Public delete goals" ON public.goals FOR DELETE USING (true);
ALTER PUBLICATION supabase_realtime ADD TABLE public.goals;
ALTER TABLE public.goals REPLICA IDENTITY FULL;

-- all_day_events
CREATE TABLE public.all_day_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  event_date date NOT NULL,
  color text NOT NULL DEFAULT '#7C3AED',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.all_day_events TO anon, authenticated;
GRANT ALL ON public.all_day_events TO service_role;
ALTER TABLE public.all_day_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read all_day_events" ON public.all_day_events FOR SELECT USING (true);
CREATE POLICY "Public insert all_day_events" ON public.all_day_events FOR INSERT WITH CHECK (true);
CREATE POLICY "Public update all_day_events" ON public.all_day_events FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "Public delete all_day_events" ON public.all_day_events FOR DELETE USING (true);
ALTER PUBLICATION supabase_realtime ADD TABLE public.all_day_events;
ALTER TABLE public.all_day_events REPLICA IDENTITY FULL;
