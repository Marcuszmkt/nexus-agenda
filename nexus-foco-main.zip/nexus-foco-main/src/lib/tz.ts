import { formatInTimeZone, fromZonedTime, toZonedTime } from "date-fns-tz";
import { ptBR } from "date-fns/locale";

export const TZ = "America/Sao_Paulo";

/** Returns "now" as a Date whose calendar fields (getHours, getDate...) reflect São Paulo. */
export function nowInTz(): Date {
  return toZonedTime(new Date(), TZ);
}

/** Convert a real UTC Date -> a Date whose local fields look like São Paulo time. */
export function toTz(date: Date): Date {
  return toZonedTime(date, TZ);
}

/**
 * Build a UTC Date from São Paulo "wall clock" parts.
 * The returned Date is the true instant; sending it to Supabase as ISO works.
 */
export function fromTzParts(year: number, month: number, day: number, hour = 0, minute = 0): Date {
  // month is 0-indexed
  const mm = String(month + 1).padStart(2, "0");
  const dd = String(day).padStart(2, "0");
  const hh = String(hour).padStart(2, "0");
  const mi = String(minute).padStart(2, "0");
  const iso = `${year}-${mm}-${dd}T${hh}:${mi}:00`;
  return fromZonedTime(iso, TZ);
}

/** Combine a São Paulo "day" (a zoned Date) with HH:mm time string -> real UTC Date. */
export function combineZonedDayAndTime(zonedDay: Date, time: string): Date {
  const [h, m] = time.split(":").map(Number);
  return fromTzParts(
    zonedDay.getFullYear(),
    zonedDay.getMonth(),
    zonedDay.getDate(),
    h,
    m,
  );
}

export function formatTz(date: Date, fmt: string): string {
  return formatInTimeZone(date, TZ, fmt, { locale: ptBR });
}
