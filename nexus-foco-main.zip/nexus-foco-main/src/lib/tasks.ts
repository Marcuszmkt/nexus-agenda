import { supabase } from "@/integrations/supabase/client";

export type TaskPriority = "important" | "common";

export type Task = {
  id: string;
  title: string;
  scheduled_date: string; // YYYY-MM-DD
  scheduled_time: string | null; // HH:mm:ss or HH:mm
  completed: boolean;
  priority: TaskPriority;
  created_at: string;
};

export async function fetchTasks(): Promise<Task[]> {
  const { data, error } = await supabase
    .from("tasks")
    .select("*")
    .order("scheduled_date", { ascending: true })
    .order("scheduled_time", { ascending: true, nullsFirst: true });
  if (error) throw error;
  return data as Task[];
}

export async function createTask(input: { title: string; scheduled_date: string; scheduled_time: string | null }) {
  const { error } = await supabase.from("tasks").insert(input);
  if (error) throw error;
}

export async function toggleTask(id: string, completed: boolean) {
  const { error } = await supabase.from("tasks").update({ completed }).eq("id", id);
  if (error) throw error;
}

export async function deleteTask(id: string) {
  const { error } = await supabase.from("tasks").delete().eq("id", id);
  if (error) throw error;
}
