import { supabase } from "@/integrations/supabase/client";

export type EventPriority = "important" | "common";

export type EventRow = {
  id: string;
  title: string;
  description: string | null;
  start_at: string;
  end_at: string;
  color: string;
  priority: EventPriority;
  created_at: string;
  updated_at: string;
};

export type CalendarEvent = {
  id: string;
  title: string;
  description: string | null;
  start: Date;
  end: Date;
  color: string;
  priority: EventPriority;
};

function fromRow(row: EventRow): CalendarEvent {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    start: new Date(row.start_at),
    end: new Date(row.end_at),
    color: row.color,
    priority: (row.priority as EventPriority) ?? "common",
  };
}

export async function fetchEvents(): Promise<CalendarEvent[]> {
  const { data, error } = await supabase
    .from("events")
    .select("*")
    .order("start_at", { ascending: true });
  if (error) throw error;
  return (data as EventRow[]).map(fromRow);
}

export async function createEvent(input: {
  title: string;
  description?: string | null;
  start: Date;
  end: Date;
  color: string;
  priority?: EventPriority;
}) {
  const { error } = await supabase.from("events").insert({
    title: input.title,
    description: input.description ?? null,
    start_at: input.start.toISOString(),
    end_at: input.end.toISOString(),
    color: input.color,
    priority: input.priority ?? "common",
  });
  if (error) throw error;
}

export async function updateEvent(id: string, input: {
  title: string;
  description?: string | null;
  start: Date;
  end: Date;
  color: string;
  priority?: EventPriority;
}) {
  const { error } = await supabase
    .from("events")
    .update({
      title: input.title,
      description: input.description ?? null,
      start_at: input.start.toISOString(),
      end_at: input.end.toISOString(),
      color: input.color,
      priority: input.priority ?? "common",
      updated_at: new Date().toISOString(),
    })
    .eq("id", id);
  if (error) throw error;
}

export async function deleteEvent(id: string) {
  const { error } = await supabase.from("events").delete().eq("id", id);
  if (error) throw error;
}

export const EVENT_COLORS = [
  "#4285F4",
  "#34A853",
  "#FBBC04",
  "#EA4335",
  "#A142F4",
  "#FF7043",
];
