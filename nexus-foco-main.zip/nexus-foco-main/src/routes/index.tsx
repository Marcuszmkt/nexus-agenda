import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Plus,
  Trash2,
  Trophy,
  Calendar as CalendarIcon,
  Clock,
  CheckCircle2,
  Circle,
  Target,
  ArrowRight,
  Minus,
  Flame,
  ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { useTasks } from "@/hooks/use-tasks";
import { useGoals } from "@/hooks/use-goals";
import { useEvents } from "@/hooks/use-events";
import { useAllDayEvents } from "@/hooks/use-all-day-events";
import { deleteTask, toggleTask, type Task } from "@/lib/tasks";
import {
  createGoal,
  deleteGoal,
  setGoalProgress,
  toggleGoal,
  goalProgressPct,
  type Goal,
  type GoalType,
} from "@/lib/goals";
import { createEvent, type CalendarEvent, type EventPriority } from "@/lib/events";
import {
  createAllDayEvent,
  deleteAllDayEvent,
  type AllDayEvent,
} from "@/lib/all-day-events";
import { combineZonedDayAndTime, formatTz, nowInTz } from "@/lib/tz";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Home — Minha Agenda" },
      { name: "description", content: "Seu painel de produtividade pessoal." },
    ],
  }),
  component: HomePage,
});

function getGreeting(hour: number) {
  if (hour >= 6 && hour < 12) return { text: "Bom dia", emoji: "☀️" };
  if (hour >= 12 && hour < 18) return { text: "Boa tarde", emoji: "🌤️" };
  return { text: "Boa noite", emoji: "🌙" };
}

type Period = "day" | "week" | "month" | "year";

type TimelineItem =
  | { kind: "task"; id: string; date: string; time: string | null; sortKey: string; task: Task }
  | { kind: "event"; id: string; date: string; time: string; sortKey: string; event: CalendarEvent }
  | { kind: "all_day"; id: string; date: string; time: null; sortKey: string; allDay: AllDayEvent };

function HomePage() {
  // Avoid hydration mismatch: render time-of-day greeting only on client
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const now = nowInTz();
  const todayStr = formatTz(now, "yyyy-MM-dd");
  const hourStr = formatTz(now, "H");
  const greeting = mounted ? getGreeting(parseInt(hourStr, 10)) : { text: "Olá", emoji: "👋" };

  const { data: tasks = [] } = useTasks();
  const { data: goals = [] } = useGoals(2026);
  const { data: events = [] } = useEvents();
  const { data: allDayEvents = [] } = useAllDayEvents();

  // ---- Today data ----
  const todayTasks = useMemo(
    () => tasks.filter((t) => t.scheduled_date === todayStr),
    [tasks, todayStr],
  );
  const completedToday = todayTasks.filter((t) => t.completed).length;
  const importantToday = useMemo(() => {
    return (
      todayTasks.filter((t) => t.priority === "important").length +
      events.filter(
        (ev) => formatTz(ev.start, "yyyy-MM-dd") === todayStr && ev.priority === "important",
      ).length +
      allDayEvents.filter((e) => e.event_date === todayStr && e.priority === "important").length
    );
  }, [todayTasks, events, allDayEvents, todayStr]);
  const commonToday = useMemo(() => {
    return (
      todayTasks.filter((t) => t.priority !== "important").length +
      events.filter(
        (ev) => formatTz(ev.start, "yyyy-MM-dd") === todayStr && ev.priority !== "important",
      ).length +
      allDayEvents.filter((e) => e.event_date === todayStr && e.priority !== "important").length
    );
  }, [todayTasks, events, allDayEvents, todayStr]);

  const upcomingEvents = useMemo(
    () =>
      events
        .filter((ev) => ev.end.getTime() >= now.getTime())
        .sort((a, b) => a.start.getTime() - b.start.getTime()),
    [events, now],
  );
  const nextEvent = upcomingEvents[0];
  const completedGoals = goals.filter((g) => g.completed).length;

  // ---- Period for "Resumo" ----
  const [period, setPeriod] = useState<Period>("day");
  const range = useMemo(() => periodRange(now, period), [now, period]);

  const timelineItems: TimelineItem[] = useMemo(() => {
    const items: TimelineItem[] = [];
    for (const t of tasks) {
      if (t.scheduled_date < range.from || t.scheduled_date > range.to) continue;
      const time = t.scheduled_time ? t.scheduled_time.slice(0, 5) : null;
      items.push({
        kind: "task",
        id: t.id,
        date: t.scheduled_date,
        time,
        sortKey: `${t.scheduled_date} ${time ?? "99:99"}`,
        task: t,
      });
    }
    for (const ev of events) {
      const d = formatTz(ev.start, "yyyy-MM-dd");
      if (d < range.from || d > range.to) continue;
      const time = formatTz(ev.start, "HH:mm");
      items.push({ kind: "event", id: ev.id, date: d, time, sortKey: `${d} ${time}`, event: ev });
    }
    for (const a of allDayEvents) {
      if (a.event_date < range.from || a.event_date > range.to) continue;
      items.push({
        kind: "all_day",
        id: a.id,
        date: a.event_date,
        time: null,
        sortKey: `${a.event_date} 00:00`,
        allDay: a,
      });
    }
    // Important first within same sort key day
    items.sort((a, b) => {
      const pa = itemPriority(a) === "important" ? 0 : 1;
      const pb = itemPriority(b) === "important" ? 0 : 1;
      if (a.date !== b.date) return a.sortKey.localeCompare(b.sortKey);
      if (pa !== pb) return pa - pb;
      return a.sortKey.localeCompare(b.sortKey);
    });
    return items;
  }, [tasks, events, allDayEvents, range]);

  // Group by date for non-day periods
  const grouped = useMemo(() => {
    const map = new Map<string, TimelineItem[]>();
    for (const it of timelineItems) {
      if (!map.has(it.date)) map.set(it.date, []);
      map.get(it.date)!.push(it);
    }
    return Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [timelineItems]);

  return (
    <AppShell>
      <div className="h-full overflow-y-auto bg-gradient-to-br from-background via-background to-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-10 flex flex-col gap-6">
          {/* Greeting */}
          <section>
            <h2 className="text-4xl sm:text-5xl font-bold tracking-tight flex items-center gap-3">
              {greeting.text} <span>{greeting.emoji}</span>
            </h2>
            <p className="mt-2 text-sm text-muted-foreground first-letter:uppercase">
              {formatTz(now, "d 'de' MMMM 'de' yyyy, EEEE")}
            </p>
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            {/* Left column */}
            <div className="lg:col-span-3 flex flex-col gap-6">
              {/* Stat cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <StatCard
                  icon={<CheckCircle2 className="size-5" />}
                  label="Tarefas hoje"
                  value={
                    <div className="flex flex-col">
                      <span className="text-3xl font-bold">
                        <span className="text-primary">{completedToday}</span>
                        <span className="text-muted-foreground">/{todayTasks.length}</span>
                      </span>
                      {(importantToday > 0 || commonToday > 0) && (
                        <span className="text-[11px] text-muted-foreground mt-1 flex items-center gap-1">
                          {importantToday > 0 && (
                            <span className="inline-flex items-center gap-0.5 text-amber-500">
                              <Flame className="size-3" /> {importantToday} importantes
                            </span>
                          )}
                          {importantToday > 0 && commonToday > 0 && <span>·</span>}
                          {commonToday > 0 && <span>{commonToday} comuns</span>}
                        </span>
                      )}
                    </div>
                  }
                  progress={todayTasks.length ? (completedToday / todayTasks.length) * 100 : 0}
                />
                <StatCard
                  icon={<Clock className="size-5" />}
                  label="Próximo evento"
                  value={
                    nextEvent ? (
                      <div className="flex flex-col">
                        <span className="text-lg font-bold text-primary truncate">
                          {nextEvent.title}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {formatTz(nextEvent.start, "HH'h'mm")}
                        </span>
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">Nenhum</span>
                    )
                  }
                />
                <StatCard
                  icon={<Target className="size-5" />}
                  label="Metas 2026"
                  value={
                    <span className="text-3xl font-bold">
                      <span className="text-primary">{completedGoals}</span>
                      <span className="text-muted-foreground">/{goals.length}</span>
                    </span>
                  }
                  progress={goals.length ? (completedGoals / goals.length) * 100 : 0}
                />
              </div>

              {/* Add task form */}
              <AddTaskForm todayStr={todayStr} />

              {/* Resumo */}
              <section className="rounded-2xl border border-primary/15 bg-card/60 backdrop-blur p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4 gap-2 flex-wrap">
                  <h3 className="text-lg font-semibold">Resumo</h3>
                  <div className="inline-flex rounded-full bg-muted p-1 text-xs">
                    {(
                      [
                        ["day", "Hoje"],
                        ["week", "Semana"],
                        ["month", "Mês"],
                        ["year", "Ano"],
                      ] as const
                    ).map(([k, l]) => (
                      <button
                        key={k}
                        type="button"
                        onClick={() => setPeriod(k)}
                        className={`px-3 py-1 rounded-full transition-colors ${
                          period === k
                            ? "bg-primary text-primary-foreground"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {l}
                      </button>
                    ))}
                  </div>
                </div>

                {grouped.length === 0 ? (
                  <div className="text-sm text-muted-foreground py-6 text-center">
                    Nada agendado neste período. Adicione algo acima.
                  </div>
                ) : period === "day" ? (
                  <ul className="flex flex-col">
                    {(grouped[0]?.[1] ?? []).map((item) => (
                      <TimelineRow key={`${item.kind}-${item.id}`} item={item} />
                    ))}
                  </ul>
                ) : (
                  <div className="flex flex-col gap-5">
                    {grouped.map(([date, items]) => (
                      <div key={date}>
                        <div className="text-xs font-semibold text-primary mb-1 first-letter:uppercase">
                          {formatTz(new Date(`${date}T12:00:00Z`), "EEEE, d 'de' MMMM")}
                        </div>
                        <ul className="flex flex-col">
                          {items.map((item) => (
                            <TimelineRow key={`${item.kind}-${item.id}`} item={item} />
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            </div>

            {/* Right column */}
            <div className="lg:col-span-2 flex flex-col gap-6">
              <NextEventCard event={nextEvent} now={now} />
              <GoalsCard goals={goals} />
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function itemPriority(it: TimelineItem): EventPriority {
  if (it.kind === "task") return (it.task.priority as EventPriority) ?? "common";
  if (it.kind === "event") return it.event.priority;
  return it.allDay.priority;
}

function periodRange(now: Date, p: Period): { from: string; to: string } {
  const y = now.getFullYear();
  const m = now.getMonth();
  const d = now.getDate();
  if (p === "day") {
    const s = formatTz(now, "yyyy-MM-dd");
    return { from: s, to: s };
  }
  if (p === "week") {
    const start = new Date(y, m, d - now.getDay());
    const end = new Date(y, m, d - now.getDay() + 6);
    return { from: ymd(start), to: ymd(end) };
  }
  if (p === "month") {
    const start = new Date(y, m, 1);
    const end = new Date(y, m + 1, 0);
    return { from: ymd(start), to: ymd(end) };
  }
  return { from: `${y}-01-01`, to: `${y}-12-31` };
}
function ymd(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/* ---------------- Stat Card ---------------- */

function StatCard({
  icon,
  label,
  value,
  progress,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
  progress?: number;
}) {
  return (
    <div className="rounded-2xl border border-primary/15 bg-gradient-to-br from-card/80 to-primary/5 backdrop-blur p-6 shadow-[0_4px_20px_-8px_rgba(124,58,237,0.25)] hover:shadow-[0_8px_28px_-8px_rgba(124,58,237,0.4)] transition-shadow">
      <div className="flex items-center gap-2 text-muted-foreground text-sm">
        <div className="size-9 rounded-full bg-primary/15 text-primary inline-flex items-center justify-center">
          {icon}
        </div>
        <span>{label}</span>
      </div>
      <div className="mt-3">{value}</div>
      {typeof progress === "number" && (
        <div className="mt-3 h-1.5 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-purple-400 shadow-[0_0_8px_rgba(124,58,237,0.6)] transition-all"
            style={{ width: `${Math.min(100, progress)}%` }}
          />
        </div>
      )}
    </div>
  );
}

/* ---------------- Timeline row ---------------- */

function TimelineRow({ item }: { item: TimelineItem }) {
  const isTask = item.kind === "task";
  const completed = isTask ? item.task.completed : false;
  const title =
    item.kind === "task" ? item.task.title : item.kind === "event" ? item.event.title : item.allDay.title;
  const tagLabel =
    item.kind === "task" ? "Tarefa" : item.kind === "event" ? "Evento" : "Dia inteiro";
  const tagClass =
    item.kind === "task"
      ? "bg-primary/15 text-primary"
      : item.kind === "event"
        ? "bg-amber-500/15 text-amber-600 dark:text-amber-400"
        : "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400";
  const priority = itemPriority(item);

  return (
    <li
      className={`group flex items-center gap-4 py-2.5 px-2 -mx-2 rounded-lg border-b border-border/40 last:border-0 hover:bg-accent/30 transition-colors ${
        priority === "important" ? "border-l-2 border-l-amber-500 pl-3 bg-amber-500/5" : ""
      }`}
    >
      <span className="w-12 shrink-0 text-xs font-medium text-muted-foreground tabular-nums">
        {item.time ?? "--:--"}
      </span>
      <button
        type="button"
        onClick={() =>
          item.kind === "task" &&
          toggleTask(item.task.id, !item.task.completed).catch(() => toast.error("Erro"))
        }
        className="text-primary hover:scale-110 transition-transform"
        aria-label={isTask ? "Concluir tarefa" : "Item"}
        disabled={!isTask}
      >
        {completed ? <CheckCircle2 className="size-5" /> : <Circle className="size-5" />}
      </button>
      <span
        className={`flex-1 text-sm truncate flex items-center gap-1.5 ${completed ? "line-through opacity-60" : ""}`}
      >
        {priority === "important" && <Flame className="size-3.5 text-amber-500 shrink-0" />}
        {title}
      </span>
      <span className={`text-[11px] font-medium px-2 py-0.5 rounded-md ${tagClass}`}>{tagLabel}</span>
      {item.kind === "task" && (
        <button
          type="button"
          onClick={() => deleteTask(item.task.id).catch(() => toast.error("Erro"))}
          className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
          aria-label="Excluir"
        >
          <Trash2 className="size-3.5" />
        </button>
      )}
      {item.kind === "all_day" && (
        <button
          type="button"
          onClick={() => deleteAllDayEvent(item.allDay.id).catch(() => toast.error("Erro"))}
          className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
          aria-label="Excluir"
        >
          <Trash2 className="size-3.5" />
        </button>
      )}
    </li>
  );
}

/* ---------------- Add task form ---------------- */

function AddTaskForm({ todayStr }: { todayStr: string }) {
  const [expanded, setExpanded] = useState(false);
  const [title, setTitle] = useState("");
  const [allDay, setAllDay] = useState(false);
  const [dateMode, setDateMode] = useState<"today" | "tomorrow" | "custom">("today");
  const [customDate, setCustomDate] = useState(todayStr);
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("10:00");
  const [priority, setPriority] = useState<EventPriority>("common");
  const [saving, setSaving] = useState(false);

  function resolveDate(): string {
    if (dateMode === "today") return todayStr;
    if (dateMode === "tomorrow") {
      const [y, m, d] = todayStr.split("-").map(Number);
      const dt = new Date(y, m - 1, d + 1);
      return ymd(dt);
    }
    return customDate;
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) {
      toast.error("Descreva a tarefa");
      return;
    }
    setSaving(true);
    try {
      const date = resolveDate();
      if (allDay) {
        await createAllDayEvent({
          title: title.trim(),
          event_date: date,
          color: "#7C3AED",
          priority,
        });
      } else {
        const [y, mo, d] = date.split("-").map(Number);
        const zoned = new Date(y, mo - 1, d);
        const start = combineZonedDayAndTime(zoned, startTime);
        const end = combineZonedDayAndTime(zoned, endTime || addOneHour(startTime));
        await createEvent({
          title: title.trim(),
          start,
          end,
          color: "#7C3AED",
          priority,
        });
      }
      setTitle("");
      setExpanded(false);
      toast.success("Adicionado");
    } catch {
      toast.error("Erro ao adicionar");
    } finally {
      setSaving(false);
    }
  }

  return (
    <form
      onSubmit={submit}
      className="rounded-2xl border border-primary/20 bg-card/60 backdrop-blur p-4 shadow-sm"
    >
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          className="inline-flex items-center justify-center size-9 rounded-full bg-gradient-to-br from-primary to-purple-400 text-primary-foreground hover:opacity-90 transition shadow-[0_0_12px_rgba(124,58,237,0.5)]"
          aria-label="Expandir"
        >
          <Plus className={`size-4 transition-transform ${expanded ? "rotate-45" : ""}`} />
        </button>
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onFocus={() => setExpanded(true)}
          placeholder="Adicionar nova tarefa..."
          className="flex-1 border-0 bg-transparent shadow-none focus-visible:ring-0 px-0 text-base"
        />
        {!expanded && (
          <Button type="submit" disabled={saving || !title.trim()} size="sm" className="gap-1">
            <Plus className="size-4" />
            Adicionar
          </Button>
        )}
      </div>

      {expanded && (
        <div className="mt-4 flex flex-col gap-4 border-t border-border/50 pt-4">
          {/* Toggle tipo */}
          <div className="inline-flex rounded-lg bg-muted p-1 text-xs self-start">
            <button
              type="button"
              onClick={() => setAllDay(false)}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                !allDay ? "bg-primary text-primary-foreground" : "text-muted-foreground"
              }`}
            >
              Horário específico
            </button>
            <button
              type="button"
              onClick={() => setAllDay(true)}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                allDay ? "bg-primary text-primary-foreground" : "text-muted-foreground"
              }`}
            >
              Dia inteiro
            </button>
          </div>

          {/* Data */}
          <div className="flex flex-wrap items-center gap-2">
            <Label className="text-xs text-muted-foreground w-full sm:w-auto">Data</Label>
            <div className="inline-flex rounded-lg bg-muted p-1 text-xs">
              {(["today", "tomorrow", "custom"] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setDateMode(m)}
                  className={`px-3 py-1.5 rounded-md transition-colors ${
                    dateMode === m
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground"
                  }`}
                >
                  {m === "today" ? "Hoje" : m === "tomorrow" ? "Amanhã" : "Escolher"}
                </button>
              ))}
            </div>
            {dateMode === "custom" && (
              <Input
                type="date"
                value={customDate}
                onChange={(e) => setCustomDate(e.target.value)}
                className="w-auto"
              />
            )}
          </div>

          {/* Horários */}
          {!allDay && (
            <div className="flex flex-wrap items-center gap-2">
              <Label className="text-xs text-muted-foreground">Horário</Label>
              <Input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-32"
              />
              <span className="text-xs text-muted-foreground">até</span>
              <Input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                placeholder={addOneHour(startTime)}
                className="w-32"
              />
            </div>
          )}

          {/* Prioridade */}
          <div className="flex flex-wrap items-center gap-2">
            <Label className="text-xs text-muted-foreground">Prioridade</Label>
            <div className="inline-flex rounded-lg bg-muted p-1 text-xs">
              <button
                type="button"
                onClick={() => setPriority("common")}
                className={`px-3 py-1.5 rounded-md transition-colors ${
                  priority === "common" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                Comum
              </button>
              <button
                type="button"
                onClick={() => setPriority("important")}
                className={`px-3 py-1.5 rounded-md transition-colors inline-flex items-center gap-1 ${
                  priority === "important"
                    ? "bg-amber-500 text-white"
                    : "text-muted-foreground"
                }`}
              >
                <Flame className="size-3" />
                Importante
              </button>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="ghost" onClick={() => setExpanded(false)}>
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={saving || !title.trim()}
              className="gap-1 bg-gradient-to-r from-primary to-purple-400 hover:opacity-90"
            >
              <Plus className="size-4" />
              Adicionar
            </Button>
          </div>
        </div>
      )}
    </form>
  );
}

function addOneHour(t: string): string {
  const [h, m] = t.split(":").map(Number);
  const total = (h + 1) * 60 + (m || 0);
  const nh = Math.floor((total / 60) % 24);
  const nm = total % 60;
  return `${String(nh).padStart(2, "0")}:${String(nm).padStart(2, "0")}`;
}

/* ---------------- Next event spotlight ---------------- */

function NextEventCard({ event, now }: { event: CalendarEvent | undefined; now: Date }) {
  if (!event) {
    return (
      <section className="rounded-2xl border border-border bg-card/60 backdrop-blur p-6 shadow-sm">
        <h3 className="text-sm text-muted-foreground mb-3">Próximo evento em destaque</h3>
        <p className="text-sm text-muted-foreground">Nenhum evento futuro. Aproveite para planejar 🌱</p>
      </section>
    );
  }
  const diffMin = Math.max(0, Math.round((event.start.getTime() - now.getTime()) / 60000));
  const inLabel =
    diffMin < 60
      ? `Em ${diffMin} min`
      : diffMin < 60 * 24
        ? `Em ${Math.floor(diffMin / 60)}h ${diffMin % 60}m`
        : `Em ${Math.floor(diffMin / (60 * 24))}d`;

  return (
    <section className="rounded-2xl border border-border bg-card/60 backdrop-blur p-6 shadow-sm">
      <h3 className="text-sm text-muted-foreground mb-3">Próximo evento em destaque</h3>
      <div
        className="rounded-2xl p-6 text-white"
        style={{
          background: "linear-gradient(135deg, #4C1D95 0%, #7C3AED 50%, #9F67FA 100%)",
          border: "1px solid #A78BFA",
          boxShadow: "0 8px 32px rgba(124, 58, 237, 0.4)",
        }}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="size-11 rounded-xl bg-[#7C3AED] inline-flex items-center justify-center shadow-inner">
              <CalendarIcon className="size-5 text-white" />
            </div>
            <div>
              <div className="text-2xl font-bold leading-tight">{event.title}</div>
            </div>
          </div>
          <span className="shrink-0 text-xs font-medium px-2.5 py-1 rounded-md bg-white/20 text-white">
            {inLabel}
          </span>
        </div>
        <div className="mt-4 flex items-center gap-2 text-sm text-white/90">
          <Clock className="size-4" />
          {formatTz(event.start, "HH:mm")} - {formatTz(event.end, "HH:mm")}
        </div>
        {event.description && (
          <div className="mt-1 text-sm text-white/80 truncate">{event.description}</div>
        )}
        <Link
          to="/calendario"
          className="mt-4 inline-flex items-center gap-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors text-white text-sm font-medium px-3 py-2"
        >
          Ver detalhes do evento <ArrowRight className="size-4" />
        </Link>
      </div>
    </section>
  );
}

/* ---------------- Goals card ---------------- */

function GoalsCard({ goals }: { goals: Goal[] }) {
  const [allOpen, setAllOpen] = useState(false);
  return (
    <section className="rounded-2xl border border-primary/15 bg-card/60 backdrop-blur p-6 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Trophy className="size-5 text-amber-500" />
          <h3 className="text-lg font-semibold">Metas de 2026</h3>
        </div>
        <div className="flex items-center gap-1">
          {goals.length > 0 && (
            <Button
              size="sm"
              variant="ghost"
              className="text-xs text-muted-foreground hover:text-primary"
              onClick={() => setAllOpen(true)}
            >
              Ver todas
            </Button>
          )}
          <AddGoalDialog />
        </div>
      </div>

      {goals.length === 0 ? (
        <p className="text-sm text-muted-foreground py-4 text-center">
          Crie sua primeira meta para 2026.
        </p>
      ) : (
        <ul className="flex flex-col gap-4 max-h-[380px] overflow-y-auto pr-1">
          {goals.map((g) => (
            <GoalRow key={g.id} goal={g} />
          ))}
        </ul>
      )}

      <Dialog open={allOpen} onOpenChange={setAllOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Todas as metas de 2026</DialogTitle>
          </DialogHeader>
          <ul className="flex flex-col gap-4 max-h-[60vh] overflow-y-auto pr-1">
            {goals.map((g) => (
              <GoalRow key={g.id} goal={g} />
            ))}
          </ul>
        </DialogContent>
      </Dialog>
    </section>
  );
}

function GoalRow({ goal }: { goal: Goal }) {
  const pct = goalProgressPct(goal);
  const done = goal.completed || pct >= 100;
  const barColor = done ? "from-emerald-500 to-emerald-400" : "from-primary to-purple-400";
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(String(goal.current_value));

  async function inc(delta: number) {
    await setGoalProgress(goal.id, goal.current_value + delta, goal.target_value).catch(() =>
      toast.error("Erro"),
    );
  }
  async function commit() {
    const n = Number(draft);
    if (Number.isFinite(n)) {
      await setGoalProgress(goal.id, n, goal.target_value).catch(() => toast.error("Erro"));
    }
    setEditing(false);
  }

  return (
    <li className="group">
      <div className="flex items-start gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className={`font-medium text-sm truncate ${done ? "line-through opacity-70" : ""}`}>
              {goal.title}
            </span>
            {done && (
              <span className="shrink-0 text-[10px] font-semibold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-600 dark:text-emerald-400">
                Concluída ✓
              </span>
            )}
          </div>
          {goal.type === "quantity" && (
            <div className="mt-0.5 text-xs text-muted-foreground flex items-center gap-1">
              {editing ? (
                <input
                  type="number"
                  autoFocus
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onBlur={commit}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") commit();
                    if (e.key === "Escape") setEditing(false);
                  }}
                  className="w-16 px-1 py-0.5 rounded bg-background border border-border text-foreground text-xs"
                />
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setDraft(String(goal.current_value));
                    setEditing(true);
                  }}
                  className="text-primary hover:underline tabular-nums"
                >
                  {formatNum(goal.current_value)}
                </button>
              )}
              <span>de {formatNum(goal.target_value)} {goal.unit ?? ""}</span>
            </div>
          )}
        </div>
        <span className="text-sm font-semibold tabular-nums shrink-0">{pct}%</span>
        <button
          type="button"
          onClick={() => deleteGoal(goal.id).catch(() => toast.error("Erro"))}
          className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
          aria-label="Excluir meta"
        >
          <Trash2 className="size-3.5" />
        </button>
      </div>

      <div className="mt-2 h-1.5 rounded-full bg-muted overflow-hidden">
        <div
          className={`h-full bg-gradient-to-r ${barColor} shadow-[0_0_8px_rgba(124,58,237,0.5)] transition-all`}
          style={{ width: `${pct}%` }}
        />
      </div>

      <div className="mt-2 flex items-center gap-2">
        {goal.type === "unique" ? (
          <label className="inline-flex items-center gap-2 text-xs text-muted-foreground cursor-pointer">
            <Checkbox
              checked={goal.completed}
              onCheckedChange={(v) => toggleGoal(goal.id, !!v).catch(() => toast.error("Erro"))}
            />
            Marcar como concluída
          </label>
        ) : (
          <div className="inline-flex items-center gap-1">
            <button
              type="button"
              onClick={() => inc(-1)}
              className="size-7 inline-flex items-center justify-center rounded-md border border-border hover:bg-accent"
              aria-label="Diminuir"
            >
              <Minus className="size-3.5" />
            </button>
            <button
              type="button"
              onClick={() => inc(1)}
              className="size-7 inline-flex items-center justify-center rounded-md bg-primary text-primary-foreground hover:opacity-90"
              aria-label="Incrementar"
            >
              <Plus className="size-3.5" />
            </button>
          </div>
        )}
      </div>
    </li>
  );
}

function formatNum(n: number) {
  if (Number.isInteger(n)) return n.toLocaleString("pt-BR");
  return n.toLocaleString("pt-BR", { maximumFractionDigits: 2 });
}

/* ---------------- Add goal dialog ---------------- */

function AddGoalDialog() {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState<GoalType>("unique");
  const [title, setTitle] = useState("");
  const [current, setCurrent] = useState("0");
  const [target, setTarget] = useState("10");
  const [unit, setUnit] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) {
      toast.error("Dê um nome à meta");
      return;
    }
    setSaving(true);
    try {
      await createGoal({
        title: title.trim(),
        type,
        target_value: type === "quantity" ? Number(target) || 1 : 1,
        unit: type === "quantity" ? unit.trim() || null : null,
      });
      // If current > 0, update progress after creation — but we don't have the new id readily.
      // Skip for now; user can edit inline.
      setOpen(false);
      setTitle("");
      setCurrent("0");
      setTarget("10");
      setUnit("");
      setType("unique");
      toast.success("Meta adicionada");
    } catch {
      toast.error("Erro ao adicionar meta");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="ghost" className="gap-1 text-primary hover:text-primary">
          <Plus className="size-4" /> Nova
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Nova meta</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setType("unique")}
              className={`rounded-xl border p-3 text-left text-sm transition-colors ${
                type === "unique"
                  ? "border-primary bg-primary/10"
                  : "border-border hover:bg-accent"
              }`}
            >
              <div className="font-semibold">Meta única</div>
              <div className="text-xs text-muted-foreground mt-0.5">Algo que se faz uma vez</div>
            </button>
            <button
              type="button"
              onClick={() => setType("quantity")}
              className={`rounded-xl border p-3 text-left text-sm transition-colors ${
                type === "quantity"
                  ? "border-primary bg-primary/10"
                  : "border-border hover:bg-accent"
              }`}
            >
              <div className="font-semibold">Meta de quantidade</div>
              <div className="text-xs text-muted-foreground mt-0.5">Com número alvo</div>
            </button>
          </div>

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="goal-title">Título</Label>
            <Input
              id="goal-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={type === "unique" ? "Ex: Ir ao cinema" : "Ex: Ler 24 livros"}
              autoFocus
            />
          </div>

          {type === "quantity" && (
            <div className="grid grid-cols-3 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="goal-current">Valor atual</Label>
                <Input
                  id="goal-current"
                  type="number"
                  min="0"
                  value={current}
                  onChange={(e) => setCurrent(e.target.value)}
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="goal-target">Valor alvo</Label>
                <Input
                  id="goal-target"
                  type="number"
                  min="1"
                  value={target}
                  onChange={(e) => setTarget(e.target.value)}
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="goal-unit">Unidade</Label>
                <Input
                  id="goal-unit"
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  placeholder="livros, km..."
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={saving}
              className="gap-1 bg-gradient-to-r from-primary to-purple-400"
            >
              <Plus className="size-4" /> Criar meta
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
